// ── Result Profiles ──────────────────────────────────────────────────────────

export interface Profile {
  id: string;
  name: string;
  tagline: string;
  description: string;
  reflectionPrompt: string;
  smallHabit: string;
}

export const PROFILES: Record<string, Profile> = {
  CONSCIOUS_ARCHITECT: {
    id: "CONSCIOUS_ARCHITECT",
    name: "The Conscious Architect",
    tagline: "High self-awareness. Intentional action. Structured inner life.",
    description:
      "You operate with a degree of self-clarity that is uncommon. You notice your patterns, question your assumptions, and tend to align your actions with examined values. This is not effortless — it reflects a sustained practice of internal observation. The risk: over-analysis, or mistaking the map for the territory.",
    reflectionPrompt:
      "Where in your life are you performing self-awareness rather than practicing it?",
    smallHabit:
      "Once per week, write down one decision you made — and one reason you haven't fully examined.",
  },

  EMERGING_OBSERVER: {
    id: "EMERGING_OBSERVER",
    name: "The Emerging Observer",
    tagline: "Awareness is present. Patterns are visible. Integration is incomplete.",
    description:
      "You can see yourself — but not consistently. You notice patterns after they've run their course, catch yourself mid-habit rather than before it. There is genuine observational capacity here, but it activates intermittently. The gap between noticing and changing is still significant. That gap is where the real work happens.",
    reflectionPrompt:
      "What pattern have you observed in yourself that you've done nothing about — and why?",
    smallHabit:
      "End each day with one sentence: 'Today I noticed ___.' Keep a log for seven days.",
  },

  REACTIVE_NAVIGATOR: {
    id: "REACTIVE_NAVIGATOR",
    name: "The Reactive Navigator",
    tagline: "High reactivity. Some pattern recognition. Low intentional direction.",
    description:
      "You move fast through life — responding, adjusting, solving. You're not unaware, but awareness tends to arrive after the response, not before it. You've likely noticed recurring patterns but haven't yet made them legible. The navigation is real; the compass is still being calibrated.",
    reflectionPrompt:
      "What do you consistently react to that you've never sat still long enough to understand?",
    smallHabit:
      "After a strong emotional reaction this week, wait 20 minutes before responding. Write what changed.",
  },

  AUTOPILOT_DRIFTER: {
    id: "AUTOPILOT_DRIFTER",
    name: "The Autopilot Drifter",
    tagline: "Low self-monitoring. Habit-driven. Externally oriented.",
    description:
      "Most of your life runs on automatic. This is not a moral failure — it's the default state. The question is whether it's chosen or simply inherited. You likely experience yourself as mostly fine, mostly functional. But when you look closely at why you do what you do, the reasons are often absent or borrowed.",
    reflectionPrompt:
      "Name one thing you do every week that you have never once consciously decided to do.",
    smallHabit:
      "Pick one routine tomorrow. Before you begin it, pause for five seconds and ask: am I choosing this?",
  },
};

export const SECONDARY_TRAITS: Record<string, string> = {
  SA: "Strong introspective capacity — you look inward readily.",
  PR: "Pattern-oriented thinking — you detect recurring structures.",
  IL: "Intention-driven — you align action with examined goals.",
  RA: "High reactivity — experience tends to precede reflection.",
};

// ── Daily Reflection Prompts ─────────────────────────────────────────────────

export const DAILY_PROMPTS: string[] = [
  "What did you avoid today — and what does the avoidance protect?",
  "Name something you did on autopilot. Would you have chosen it consciously?",
  "What assumption did you act on today without questioning it?",
  "Where did your energy go? Was it directed or dispersed?",
  "What triggered a reaction in you this week? What does that reveal?",
  "Name a decision you made. What value was actually driving it?",
  "What pattern do you keep noticing but haven't changed? What would change cost?",
  "When did you last do something difficult without immediately seeking comfort?",
  "What story do you tell yourself most often? Is it useful or just familiar?",
  "What would today look like if you had been fully deliberate in it?",
];

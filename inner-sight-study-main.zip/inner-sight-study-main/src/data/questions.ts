// ── Introspection Questions ─────────────────────────────────────────────────
// Each answer maps weighted points to four dimensions:
//   SA = Self-Awareness
//   PR = Pattern Recognition
//   IL = Intentional Living
//   RA = Reactivity / Autopilot

export type Dimension = "SA" | "PR" | "IL" | "RA";

export interface Option {
  text: string;
  weights: Partial<Record<Dimension, number>>;
}

export interface Question {
  id: number;
  text: string;
  options: Option[];
}

export const QUESTIONS: Question[] = [
  {
    id: 1,
    text: "When you make a significant decision, how often do you later reflect on why you made it?",
    options: [
      { text: "Rarely — I move on without looking back.",         weights: { RA: 3 } },
      { text: "Sometimes, when things go wrong.",                 weights: { PR: 1, RA: 2 } },
      { text: "Often — I try to understand my own reasoning.",    weights: { SA: 2, PR: 1 } },
      { text: "Almost always — reflection is a habit.",           weights: { SA: 3, IL: 1 } },
    ],
  },
  {
    id: 2,
    text: "Can you distinguish between acting from habit and acting from deliberate choice?",
    options: [
      { text: "Not really — it all feels the same to me.",        weights: { RA: 3 } },
      { text: "Occasionally, after the fact.",                     weights: { PR: 1, RA: 2 } },
      { text: "Sometimes, while it's happening.",                  weights: { SA: 2, PR: 1 } },
      { text: "Yes — I notice the difference in the moment.",     weights: { SA: 3, IL: 2 } },
    ],
  },
  {
    id: 3,
    text: "How often do you examine the patterns in your emotional responses?",
    options: [
      { text: "I don't — emotions just happen.",                  weights: { RA: 3 } },
      { text: "I notice them but rarely investigate.",             weights: { PR: 1, RA: 1 } },
      { text: "I sometimes trace an emotion back to its source.", weights: { SA: 2, PR: 2 } },
      { text: "Regularly — patterns are data.",                   weights: { SA: 2, PR: 3 } },
    ],
  },
  {
    id: 4,
    text: "When something goes wrong, what is your first instinct?",
    options: [
      { text: "React immediately — fix, escape, or blame.",       weights: { RA: 3 } },
      { text: "Feel the impact, then slowly problem-solve.",      weights: { RA: 1, PR: 1 } },
      { text: "Pause to understand what actually happened.",      weights: { SA: 2, PR: 1 } },
      { text: "Analyze the event before responding.",             weights: { SA: 2, IL: 2, PR: 1 } },
    ],
  },
  {
    id: 5,
    text: "How conscious are you of the values driving your daily choices?",
    options: [
      { text: "I haven't really defined my values.",              weights: { RA: 3 } },
      { text: "I have a vague sense but nothing explicit.",       weights: { RA: 1, SA: 1 } },
      { text: "I know my values but don't always use them.",     weights: { SA: 2, IL: 1 } },
      { text: "My choices are regularly filtered through them.",  weights: { SA: 2, IL: 3 } },
    ],
  },
  {
    id: 6,
    text: "Do you notice recurring themes in your relationships — conflict styles, distances, dependencies?",
    options: [
      { text: "No — every situation feels unique.",               weights: { RA: 2 } },
      { text: "I notice sometimes, but see no pattern.",          weights: { PR: 1, RA: 1 } },
      { text: "I've noticed a few repeating dynamics.",           weights: { PR: 2, SA: 1 } },
      { text: "Yes — I've mapped them clearly.",                  weights: { PR: 3, SA: 2 } },
    ],
  },
  {
    id: 7,
    text: "How often do you act without thinking, and only understand why afterwards?",
    options: [
      { text: "Very often — I'm usually reactive.",               weights: { RA: 3 } },
      { text: "Often enough that I notice it.",                   weights: { RA: 2, PR: 1 } },
      { text: "Occasionally — usually under stress.",             weights: { RA: 1, SA: 1 } },
      { text: "Rarely — I usually catch myself first.",           weights: { SA: 3, IL: 1 } },
    ],
  },
  {
    id: 8,
    text: "When you feel a strong emotion, do you understand its source?",
    options: [
      { text: "No — emotions arrive and I just experience them.", weights: { RA: 3 } },
      { text: "Sometimes I can guess but I'm often wrong.",       weights: { PR: 1, RA: 1 } },
      { text: "Often — I can trace it if I try.",                 weights: { SA: 2, PR: 1 } },
      { text: "Usually — I have a working model of my triggers.", weights: { SA: 3, PR: 2 } },
    ],
  },
  {
    id: 9,
    text: "How often do you review how you actually spend your time versus how you intend to?",
    options: [
      { text: "Never — it would just stress me out.",             weights: { RA: 3 } },
      { text: "Rarely — I prefer not to audit myself.",           weights: { RA: 2, SA: 1 } },
      { text: "Occasionally — I do rough mental reviews.",        weights: { SA: 1, IL: 2 } },
      { text: "Regularly — time is a signal.",                    weights: { SA: 2, IL: 3 } },
    ],
  },
  {
    id: 10,
    text: "Do you recognize when external events are controlling your internal state?",
    options: [
      { text: "Not in the moment — only in hindsight.",           weights: { RA: 3 } },
      { text: "Sometimes, but I can't usually interrupt it.",     weights: { PR: 1, RA: 2 } },
      { text: "I notice it and can sometimes redirect.",          weights: { SA: 2, PR: 1 } },
      { text: "I notice it quickly and have strategies for it.",  weights: { SA: 3, IL: 2 } },
    ],
  },
  {
    id: 11,
    text: "How often do you question your own assumptions rather than act on them?",
    options: [
      { text: "Almost never — my assumptions feel like facts.",   weights: { RA: 3 } },
      { text: "Rarely — only when something breaks down.",        weights: { RA: 2, PR: 1 } },
      { text: "Sometimes — especially in high-stakes moments.",   weights: { SA: 2, PR: 1 } },
      { text: "Often — assumptions are the first thing I audit.", weights: { SA: 3, PR: 2, IL: 1 } },
    ],
  },
  {
    id: 12,
    text: "Do you notice the gap between who you intend to be and how you actually behave?",
    options: [
      { text: "No — I think I act consistently.",                 weights: { RA: 2 } },
      { text: "Vaguely — but I don't examine it.",                weights: { RA: 1, SA: 1 } },
      { text: "Yes — and it bothers me.",                         weights: { SA: 2, PR: 1 } },
      { text: "Yes — and I treat it as information.",             weights: { SA: 3, IL: 2, PR: 1 } },
    ],
  },
  {
    id: 13,
    text: "When you're under stress, how aware are you of your own coping patterns?",
    options: [
      { text: "Not at all — I just cope however I cope.",         weights: { RA: 3 } },
      { text: "I notice afterwards what I did.",                  weights: { PR: 2, RA: 1 } },
      { text: "I sometimes catch myself mid-pattern.",            weights: { SA: 2, PR: 2 } },
      { text: "I know my patterns and can observe them live.",    weights: { SA: 3, PR: 2, IL: 1 } },
    ],
  },
  {
    id: 14,
    text: "How often do your daily choices align with your stated long-term goals?",
    options: [
      { text: "Rarely — I live mostly in the immediate.",         weights: { RA: 3 } },
      { text: "Sometimes — I have intentions but drift.",         weights: { RA: 1, IL: 1 } },
      { text: "Often — I try to keep the bigger picture visible.",weights: { IL: 2, SA: 1 } },
      { text: "Consistently — daily decisions are downstream.",   weights: { IL: 3, SA: 2 } },
    ],
  },
  {
    id: 15,
    text: "At the end of a day, how clearly can you articulate what you did and why?",
    options: [
      { text: "Not clearly — days blur together.",                weights: { RA: 3 } },
      { text: "I can recount events but not reasons.",            weights: { PR: 1, RA: 2 } },
      { text: "I can usually explain my main actions.",           weights: { SA: 2, IL: 1 } },
      { text: "With precision — I know what I did and its purpose.",weights: { SA: 2, IL: 3 } },
    ],
  },
];

// Questionnaire — one question at a time with progress bar.
// Tracks session start time for completion screen.

import { useState, useEffect } from "react";
import { QUESTIONS } from "@/data/questions";
import { computeResult, type Scores, type ScoringResult } from "@/lib/scoring";

interface Props {
  onComplete: (result: ScoringResult, minutes: number) => void;
}

const EMPTY_SCORES: Scores = { SA: 0, PR: 0, IL: 0, RA: 0 };

const Questionnaire = ({ onComplete }: Props) => {
  const [current, setCurrent] = useState(0);
  const [scores, setScores] = useState<Scores>({ ...EMPTY_SCORES });
  const [selected, setSelected] = useState<number | null>(null);
  const [visible, setVisible] = useState(true);
  const [startTime] = useState(() => Date.now());

  const q = QUESTIONS[current];
  const progress = Math.round((current / QUESTIONS.length) * 100);

  // Restore session state from sessionStorage
  useEffect(() => {
    const saved = sessionStorage.getItem("introspect_progress");
    if (saved) {
      try {
        const { idx, sc } = JSON.parse(saved);
        if (typeof idx === "number" && idx < QUESTIONS.length) {
          setCurrent(idx);
          setScores(sc);
        }
      } catch {}
    }
  }, []);

  const handleSelect = (optionIdx: number) => {
    if (selected !== null) return; // prevent double-click
    setSelected(optionIdx);
  };

  const handleNext = () => {
    if (selected === null) return;

    // Accumulate weights
    const weights = q.options[selected].weights;
    const next: Scores = { ...scores };
    for (const [dim, val] of Object.entries(weights)) {
      next[dim as keyof Scores] += val as number;
    }

    const nextIdx = current + 1;

    // Persist partial progress
    sessionStorage.setItem(
      "introspect_progress",
      JSON.stringify({ idx: nextIdx, sc: next })
    );

    if (nextIdx >= QUESTIONS.length) {
      // Done
      sessionStorage.removeItem("introspect_progress");
      const elapsed = Math.max(1, Math.round((Date.now() - startTime) / 60000));
      onComplete(computeResult(next), elapsed);
      return;
    }

    // Animate out → update → animate in
    setVisible(false);
    setTimeout(() => {
      setScores(next);
      setCurrent(nextIdx);
      setSelected(null);
      setVisible(true);
    }, 280);
  };

  return (
    <section id="questionnaire" className="q-section">
      <div className="q-container">
        {/* Header */}
        <div className="q-header">
          <p className="label-tag">introspection module</p>
          <span className="mono q-counter">
            {String(current + 1).padStart(2, "0")} /{" "}
            {String(QUESTIONS.length).padStart(2, "0")}
          </span>
        </div>

        {/* Progress bar */}
        <div className="progress-track q-progress">
          <div className="progress-fill" style={{ width: `${progress}%` }} />
        </div>

        {/* Question card */}
        <div className={`q-card fade-in ${visible ? "q-visible" : "q-hidden"}`}>
          <p className="q-text">{q.text}</p>

          <div className="q-options">
            {q.options.map((opt, i) => (
              <button
                key={i}
                className={`option-btn ${selected === i ? "selected" : ""}`}
                onClick={() => handleSelect(i)}
              >
                <span className="mono option-letter">
                  {String.fromCharCode(65 + i)}.
                </span>{" "}
                {opt.text}
              </button>
            ))}
          </div>

          <div className="q-actions">
            <button
              className="btn-primary"
              onClick={handleNext}
              disabled={selected === null}
              style={{ opacity: selected === null ? 0.4 : 1 }}
            >
              {current + 1 === QUESTIONS.length ? "Complete →" : "Next →"}
            </button>
          </div>
        </div>
      </div>

      <style>{`
        .q-section {
          padding: 5rem 1.5rem;
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .q-container {
          max-width: 680px;
          width: 100%;
        }
        .q-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }
        .q-counter {
          font-size: 0.7rem;
          color: hsl(var(--dim));
        }
        .q-progress {
          margin-bottom: 2.5rem;
        }
        .q-card {
          transition: opacity 0.28s ease, transform 0.28s ease;
        }
        .q-hidden {
          opacity: 0;
          transform: translateY(10px);
          pointer-events: none;
        }
        .q-visible {
          opacity: 1;
          transform: translateY(0);
        }
        .q-text {
          font-size: clamp(1.05rem, 2.5vw, 1.3rem);
          font-weight: 300;
          color: hsl(var(--foreground));
          margin-bottom: 2rem;
          line-height: 1.6;
        }
        .q-options {
          display: flex;
          flex-direction: column;
          gap: 0.6rem;
          margin-bottom: 2rem;
        }
        .option-letter {
          font-size: 0.7rem;
          color: hsl(var(--dim));
          margin-right: 0.3rem;
        }
        .q-actions {
          display: flex;
          justify-content: flex-end;
        }
      `}</style>
    </section>
  );
};

export default Questionnaire;

// DiscussionWall — localStorage-backed reflection entries.
// Anonymous if name is left blank. Max 200 chars per entry.

import { useState, useEffect } from "react";

interface Entry {
  name: string;
  text: string;
  ts: number; // Unix ms timestamp
}

const STORAGE_KEY = "introspect_wall";
const MAX_CHARS = 300;

const DiscussionWall = () => {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  // Load from localStorage
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setEntries(JSON.parse(raw));
    } catch {}
  }, []);

  const persist = (next: Entry[]) => {
    setEntries(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) {
      setError("Reflection cannot be empty.");
      return;
    }
    if (trimmed.length > MAX_CHARS) {
      setError(`Maximum ${MAX_CHARS} characters.`);
      return;
    }
    setError("");

    const entry: Entry = {
      name: name.trim() || "Anonymous",
      text: trimmed,
      ts: Date.now(),
    };

    persist([entry, ...entries]);
    setName("");
    setText("");
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <section className="wall-section">
      <div className="wall-container">
        <div className="wall-header">
          <p className="label-tag">memory box</p>
          <h2 className="section-title">
            What did you experience this week that you do not want to forget?
          </h2>
        </div>

        {/* Input form */}
        <form className="wall-form lab-card" onSubmit={handleSubmit}>
          <div className="wall-form-row">
            <div className="wall-field">
              <label className="label-tag wall-field-label" htmlFor="wall-name">
                name (optional)
              </label>
              <input
                id="wall-name"
                className="wall-input"
                type="text"
                placeholder="Anonymous"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={50}
              />
            </div>
          </div>

          <div className="wall-field">
            <label className="label-tag wall-field-label" htmlFor="wall-text">
              memory — {MAX_CHARS - text.length} chars remaining
            </label>
            <textarea
              id="wall-text"
              className="wall-textarea"
              placeholder="This week I experienced..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={MAX_CHARS}
              rows={3}
            />
          </div>

          {error && <p className="wall-error">{error}</p>}

          <div className="wall-submit-row">
            <button className="btn-primary" type="submit">
              Submit
            </button>
          </div>
        </form>

        {/* Entries */}
        {entries.length === 0 ? (
          <p className="wall-empty label-tag">No entries yet. Be the first.</p>
        ) : (
          <div className="wall-entries">
            {entries.map((entry, i) => (
              <div key={i} className="wall-entry lab-card">
                <div className="wall-entry-header">
                  <span className="mono wall-entry-name">{entry.name}</span>
                  <span className="label-tag wall-entry-time">
                    {formatTime(entry.ts)}
                  </span>
                </div>
                <p className="wall-entry-text">{entry.text}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <style>{`
        .wall-section {
          padding: 4rem 1.5rem 6rem;
          border-top: 1px solid hsl(var(--border));
        }
        .wall-container {
          max-width: 680px;
          margin: 0 auto;
        }
        .wall-header {
          margin-bottom: 2rem;
        }
        .wall-header .label-tag {
          display: block;
          margin-bottom: 0.75rem;
        }
        .wall-sub {
          font-size: 0.8rem;
          color: hsl(var(--dim));
          margin-top: 0.5rem;
        }
        .wall-form {
          margin-bottom: 2rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }
        .wall-field {
          display: flex;
          flex-direction: column;
          gap: 0.4rem;
        }
        .wall-field-label {
          display: block;
        }
        .wall-input, .wall-textarea {
          width: 100%;
          background: hsl(var(--input));
          border: 1px solid hsl(var(--border));
          border-radius: var(--radius);
          color: hsl(var(--foreground));
          font-family: 'Inter', sans-serif;
          font-size: 0.875rem;
          padding: 0.65rem 0.9rem;
          outline: none;
          transition: border-color 0.18s ease;
          resize: vertical;
        }
        .wall-input:focus, .wall-textarea:focus {
          border-color: hsl(var(--primary));
        }
        .wall-input::placeholder, .wall-textarea::placeholder {
          color: hsl(var(--dim));
        }
        .wall-error {
          font-size: 0.8rem;
          color: hsl(var(--destructive));
          font-family: 'Space Mono', monospace;
        }
        .wall-submit-row {
          display: flex;
          justify-content: flex-end;
        }
        .wall-empty {
          text-align: center;
          padding: 2rem 0;
          display: block;
        }
        .wall-entries {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }
        .wall-entry {
          transition: none;
        }
        .wall-entry-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 0.5rem;
        }
        .wall-entry-name {
          font-size: 0.75rem;
          color: hsl(var(--primary));
        }
        .wall-entry-time {
          font-size: 0.6rem;
        }
        .wall-entry-text {
          font-size: 0.875rem;
          color: hsl(var(--muted-foreground));
          line-height: 1.65;
        }
      `}</style>
    </section>
  );
};

export default DiscussionWall;

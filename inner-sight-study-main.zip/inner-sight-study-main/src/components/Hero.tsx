// Hero section — "Don't Just Exist. Live."
// Scroll-links to #questionnaire on CTA click.

const Hero = () => {
  const handleBegin = () => {
    const el = document.getElementById("questionnaire");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="hero-section">
      <div className="hero-inner">
        <h1 className="hero-headline">
          Don't Just Exist.<br />
          <span className="hero-accent">Live.</span>
        </h1>

        <p className="hero-sub">Living begins with awareness.</p>

        <button className="btn-primary hero-cta" onClick={handleBegin}>
          Begin Reflection <span className="mono">→</span>
        </button>

        {/* Status row */}
        <div className="hero-meta">
          <span className="label-tag">15 questions</span>
          <span className="hero-dot" />
          <span className="label-tag">~4 minutes</span>
          <span className="hero-dot" />
          <span className="label-tag">no account required</span>
        </div>
      </div>

      <style>{`
        .hero-section {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 5rem 1.5rem;
        }
        .hero-inner {
          max-width: 680px;
          width: 100%;
        }
        .hero-tag {
          margin-bottom: 2.5rem;
          display: block;
        }
        .hero-headline {
          font-size: clamp(2.8rem, 8vw, 5.5rem);
          font-weight: 700;
          line-height: 1.05;
          color: hsl(var(--foreground));
          margin-bottom: 1.5rem;
        }
        .hero-accent {
          color: hsl(var(--primary));
        }
        .hero-sub {
          font-size: clamp(1rem, 2.5vw, 1.2rem);
          color: hsl(var(--muted-foreground));
          margin-bottom: 2.5rem;
          font-weight: 300;
        }
        .hero-cta {
          font-size: 0.85rem;
          padding: 0.75rem 1.75rem;
          margin-bottom: 2.5rem;
        }
        .hero-meta {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          flex-wrap: wrap;
        }
        .hero-dot {
          width: 3px;
          height: 3px;
          border-radius: 50%;
          background: hsl(var(--dim));
        }
      `}</style>
    </section>
  );
};

export default Hero;

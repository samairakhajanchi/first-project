// DailyPrompt — picks a random prompt from DAILY_PROMPTS on page load.
// No storage required — pure in-memory random selection.

import { useMemo } from "react";
import { DAILY_PROMPTS } from "@/data/profiles";

const DailyPrompt = () => {
  const prompt = useMemo(
    () => DAILY_PROMPTS[Math.floor(Math.random() * DAILY_PROMPTS.length)],
    []
  );

  return (
    <section className="dp-section">
      <div className="dp-container">
        <p className="label-tag dp-label">daily reflection prompt</p>
        <div className="dp-card">
          <p className="dp-cursor mono blink">{">"}</p>
          <p className="dp-text">{prompt}</p>
        </div>
        
      </div>

      <style>{`
        .dp-section {
          padding: 4rem 1.5rem;
          border-top: 1px solid hsl(var(--border));
        }
        .dp-container {
          max-width: 680px;
          margin: 0 auto;
        }
        .dp-label {
          margin-bottom: 1.25rem;
          display: block;
        }
        .dp-card {
          background: hsl(var(--card));
          border: 1px solid hsl(var(--border));
          border-radius: var(--radius);
          padding: 1.75rem 1.5rem;
          display: flex;
          gap: 1rem;
          align-items: flex-start;
        }
        .dp-cursor {
          color: hsl(var(--primary));
          font-size: 1.1rem;
          flex-shrink: 0;
          line-height: 1.6;
        }
        .dp-text {
          font-size: clamp(1rem, 2.5vw, 1.2rem);
          color: hsl(var(--foreground));
          font-weight: 300;
          line-height: 1.65;
        }
        .dp-hint {
          margin-top: 0.75rem;
          display: block;
        }
      `}</style>
    </section>
  );
};

export default DailyPrompt;

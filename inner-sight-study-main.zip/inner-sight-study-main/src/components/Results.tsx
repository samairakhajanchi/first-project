// Results / Completion screen
// Shows: time spent, profile, secondary trait, insight, reflection prompt, small habit.
// Also renders dimension score bars.

import { useEffect, useState } from "react";
import { type ScoringResult } from "@/lib/scoring";
import { scoresAsPercent } from "@/lib/scoring";

const DIMENSION_LABELS: Record<string, string> = {
  SA: "Self-Awareness",
  PR: "Pattern Recognition",
  IL: "Intentional Living",
  RA: "Reactivity / Autopilot",
};

interface Props {
  result: ScoringResult;
  minutes: number;
  onReset: () => void;
}

const Results = ({ result, minutes, onReset }: Props) => {
  const { profile, secondaryDimension, secondaryTrait, scores } = result;
  const pct = scoresAsPercent(scores);
  const [rendered, setRendered] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setRendered(true), 100);
    window.scrollTo({ top: 0, behavior: "smooth" });
    return () => clearTimeout(t);
  }, []);

  return (
    <section className="res-section fade-in">
      <div className="res-container">

        {/* Time stamp */}
        <div className="res-time-block lab-card">
          <p className="label-tag">session complete</p>
          <p className="res-time-text">
            You spent{" "}
            <span className="mono res-minutes">{minutes}</span>{" "}
            {minutes === 1 ? "minute" : "minutes"} observing yourself.
          </p>
        </div>

        {/* Primary profile */}
        <div className="lab-card res-profile-card">
          <p className="label-tag">primary profile</p>
          <h2 className="res-profile-name">{profile.name}</h2>
          <p className="res-tagline mono">{profile.tagline}</p>
          <p className="res-desc">{profile.description}</p>
        </div>

        {/* Secondary trait */}
        <div className="lab-card res-secondary">
          <p className="label-tag">secondary trait — {DIMENSION_LABELS[secondaryDimension]}</p>
          <p className="res-trait-text">{secondaryTrait}</p>
        </div>

        {/* Dimension bars */}
        <div className="lab-card">
          <p className="label-tag" style={{ marginBottom: "1.25rem" }}>dimension breakdown</p>
          <div className="res-bars">
            {(Object.keys(pct) as (keyof typeof pct)[]).map((dim) => (
              <div key={dim} className="res-bar-row">
                <div className="res-bar-label">
                  <span className="mono res-dim-code">{dim}</span>
                  <span className="res-dim-name">{DIMENSION_LABELS[dim]}</span>
                </div>
                <div className="dimension-bar res-bar-track">
                  <div
                    className="dimension-fill"
                    style={{
                      width: rendered ? `${pct[dim]}%` : "0%",
                    }}
                  />
                </div>
                <span className="mono res-bar-pct">{pct[dim]}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Reflection prompt */}
        <div className="lab-card res-prompt-card">
          <p className="label-tag">reflection prompt</p>
          <p className="res-prompt-text">"{profile.reflectionPrompt}"</p>
        </div>

        {/* Small habit */}
        <div className="lab-card res-habit-card">
          <p className="label-tag">one small habit</p>
          <p className="res-habit-text">{profile.smallHabit}</p>
        </div>

        {/* Reset */}
        <div className="res-reset">
          <button className="btn-outline" onClick={onReset}>
            ← Start over
          </button>
        </div>
      </div>

      <style>{`
        .res-section {
          padding: 5rem 1.5rem;
          min-height: 100vh;
        }
        .res-container {
          max-width: 680px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }
        .res-time-block {
          background: hsl(var(--surface));
          border-color: hsl(var(--line));
        }
        .res-time-text {
          font-size: 1rem;
          color: hsl(var(--foreground));
          margin-top: 0.5rem;
        }
        .res-minutes {
          color: hsl(var(--primary));
          font-size: 1.4rem;
        }
        .res-profile-card {
          border-color: hsl(var(--primary));
        }
        .res-profile-name {
          font-size: clamp(1.4rem, 4vw, 2rem);
          font-weight: 700;
          color: hsl(var(--foreground));
          margin: 0.5rem 0 0.4rem;
        }
        .res-tagline {
          font-size: 0.7rem;
          color: hsl(var(--primary));
          letter-spacing: 0.05em;
          margin-bottom: 1rem;
        }
        .res-desc {
          font-size: 0.9rem;
          color: hsl(var(--muted-foreground));
          line-height: 1.7;
        }
        .res-secondary {
          border-color: hsl(var(--line));
        }
        .res-trait-text {
          margin-top: 0.5rem;
          font-size: 0.9rem;
          color: hsl(var(--muted-foreground));
        }
        .res-bars {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }
        .res-bar-row {
          display: grid;
          grid-template-columns: 1fr 2fr auto;
          align-items: center;
          gap: 1rem;
        }
        .res-bar-label {
          display: flex;
          flex-direction: column;
          gap: 0.15rem;
        }
        .res-dim-code {
          font-size: 0.65rem;
          color: hsl(var(--primary));
        }
        .res-dim-name {
          font-size: 0.7rem;
          color: hsl(var(--muted-foreground));
        }
        .res-bar-track {
          flex: 1;
        }
        .res-bar-pct {
          font-size: 0.65rem;
          color: hsl(var(--dim));
          min-width: 30px;
          text-align: right;
        }
        .res-prompt-card {
          background: hsl(210 58% 52% / 0.06);
          border-color: hsl(var(--blue-dim));
        }
        .res-prompt-text {
          font-size: 1rem;
          color: hsl(var(--foreground));
          font-style: italic;
          margin-top: 0.75rem;
          line-height: 1.65;
        }
        .res-habit-card {
          border-color: hsl(var(--line));
        }
        .res-habit-text {
          font-size: 0.9rem;
          color: hsl(var(--muted-foreground));
          margin-top: 0.5rem;
          line-height: 1.65;
        }
        .res-reset {
          padding-top: 1rem;
        }
      `}</style>
    </section>
  );
};

export default Results;

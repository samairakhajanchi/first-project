// Scoring utilities — maps raw dimension scores to a profile.

import { PROFILES, SECONDARY_TRAITS, type Profile } from "@/data/profiles";

export type Dimension = "SA" | "PR" | "IL" | "RA";

export interface Scores {
  SA: number;
  PR: number;
  IL: number;
  RA: number;
}

export interface ScoringResult {
  profile: Profile;
  secondaryDimension: Dimension;
  secondaryTrait: string;
  scores: Scores;
  dominantDimension: Dimension;
}

/** Determine primary profile from dimension scores */
export function computeResult(scores: Scores): ScoringResult {
  // Rank dimensions by score
  const ranked = (Object.entries(scores) as [Dimension, number][]).sort(
    (a, b) => b[1] - a[1]
  );

  const dominant = ranked[0][0];
  const secondary = ranked[1][0];

  // Map dominant → profile
  let profile: Profile;
  if (dominant === "SA" && scores.IL >= scores.RA) {
    profile = PROFILES.CONSCIOUS_ARCHITECT;
  } else if (dominant === "SA" || (dominant === "PR" && scores.SA > scores.RA)) {
    profile = PROFILES.EMERGING_OBSERVER;
  } else if (dominant === "PR" || (dominant === "RA" && scores.PR > scores.SA)) {
    profile = PROFILES.REACTIVE_NAVIGATOR;
  } else {
    profile = PROFILES.AUTOPILOT_DRIFTER;
  }

  return {
    profile,
    dominantDimension: dominant,
    secondaryDimension: secondary,
    secondaryTrait: SECONDARY_TRAITS[secondary] ?? "",
    scores,
  };
}

/** Convert absolute scores to percentages (0-100) for display */
export function scoresAsPercent(scores: Scores): Scores {
  const max = Math.max(...Object.values(scores), 1);
  return {
    SA: Math.round((scores.SA / max) * 100),
    PR: Math.round((scores.PR / max) * 100),
    IL: Math.round((scores.IL / max) * 100),
    RA: Math.round((scores.RA / max) * 100),
  };
}

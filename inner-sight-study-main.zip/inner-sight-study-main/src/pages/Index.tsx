// Main page — orchestrates all sections.
// State machine: "hero" | "questionnaire" | "results"

import { useState } from "react";
import Hero from "@/components/Hero";
import Questionnaire from "@/components/Questionnaire";
import Results from "@/components/Results";
import DailyPrompt from "@/components/DailyPrompt";
import DiscussionWall from "@/components/DiscussionWall";
import { type ScoringResult } from "@/lib/scoring";

type Phase = "hero" | "questionnaire" | "results";

const Index = () => {
  const [phase, setPhase] = useState<Phase>("hero");
  const [result, setResult] = useState<ScoringResult | null>(null);
  const [minutes, setMinutes] = useState(0);

  const handleComplete = (r: ScoringResult, m: number) => {
    setResult(r);
    setMinutes(m);
    setPhase("results");
  };

  const handleReset = () => {
    setResult(null);
    setMinutes(0);
    setPhase("hero");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="app-root">
      {/* ── Navbar ── */}
      <nav className="app-nav">
        <span className="mono nav-logo">introspect.</span>
        <span className="label-tag nav-build">build 1.0</span>
      </nav>

      {/* ── Main content ── */}
      <main>
        {phase === "hero" && (
          <>
            <Hero />
            <div id="questionnaire">
              <Questionnaire onComplete={handleComplete} />
            </div>
          </>
        )}

        {phase === "questionnaire" && (
          <Questionnaire onComplete={handleComplete} />
        )}

        {phase === "results" && result && (
          <Results result={result} minutes={minutes} onReset={handleReset} />
        )}
      </main>

      {/* ── Always-visible sections ── */}
      <DailyPrompt />
      <DiscussionWall />

      {/* ── Footer ── */}
      <footer className="app-footer">
        <span className="label-tag">
          introspect — a quiet laboratory for self-observation
        </span>
        <span className="label-tag">no data collected · no account required</span>
      </footer>

      <style>{`
        .app-root {
          min-height: 100vh;
        }
        .app-nav {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          z-index: 50;
          padding: 1rem 1.5rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: hsl(var(--background) / 0.92);
          backdrop-filter: blur(8px);
          border-bottom: 1px solid hsl(var(--border));
        }
        .nav-logo {
          font-size: 0.9rem;
          color: hsl(var(--foreground));
          letter-spacing: -0.02em;
        }
        .nav-build {
          font-size: 0.6rem;
        }
        main {
          padding-top: 56px; /* nav height */
        }
        .app-footer {
          padding: 1.5rem 1.5rem;
          border-top: 1px solid hsl(var(--border));
          display: flex;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 0.5rem;
        }
        @media (max-width: 480px) {
          .app-footer {
            flex-direction: column;
          }
        }
      `}</style>
    </div>
  );
};

export default Index;
